import os
import pystyle
import time
import colorama 
import ctypes
import time
from pystyle import Colorate, Colors

import requests

def changer_titre(nouveau_titre):
    ctypes.windll.kernel32.SetConsoleTitleW(nouveau_titre)

def envoyer_message_via_webhook(webhook_url, message, nombre_messages):
    for _ in range(nombre_messages):
        data = {"content": message}
        response = requests.post(webhook_url, json=data)
        if response.status_code == 200:
            print(f"Message envoyé avec succès ({_ + 1}/{nombre_messages}).")
        else:
            print(f"erreur. Reverif : {response.status_code}")

changer_titre("X-Logger by wojack team and ochy")

font = ("""
                               ██╗  ██╗     ██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
                               ╚██╗██╔╝     ██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
                                ╚███╔╝█████╗██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
                                ██╔██╗╚════╝██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
                               ██╔╝ ██╗     ███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
                               ╚═╝  ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
""")

options = ("""
Options:
                               ╔═══════════════════════════════════════════════╗
                               ║1) RAT                7) Ransomware builder    ║
                               ║2) Spam report        8) id to token           ║
                               ║3) nitro gen          9) discord               ║
                               ║4) webhook spammer    10) credits              ║   
                               ║5) mail bomber                                 ║
                               ║6) stealer                                     ║
                               ╚═══════════════════════════════════════════════╝
""")

print(Colorate.Vertical(Colors.blue_to_red, font + options))

choix_utilisateur = input("Choisissez une option : ")

def Start (nom_exe):
    print(f"Start {nom_exe}...")
    os.system(nom_exe) 
if choix_utilisateur == "1":
    print ("soon...")
    time.sleep(3)
elif choix_utilisateur == "2":
    Start ("SpamReport.py")
elif choix_utilisateur == "3":
    Start ("LoggerNitro.py")
elif choix_utilisateur == "4":
    webhook_url = input("Entrez votre webhook : ")
    message = input("Entrez le message à envoyer : ")
    nombre_messages = int(input("Entrez le nombre de messages à envoyer : "))
    envoyer_message_via_webhook(webhook_url, message, nombre_messages)
elif choix_utilisateur == "5":
    Start ("mailbomber.py")
elif choix_utilisateur == "6":
    Start ("ConfigStealer.txt")
elif choix_utilisateur == "7":
    print ("soon...")
    time.sleep(3)
elif choix_utilisateur == "8":
    Start ("LoggerIDtoTOKEN.py")
elif choix_utilisateur == "9":
    print ("discord.gg/wojack")
    time.sleep(5)
elif choix_utilisateur == "10":
    print ("rick rolledddd")
    time.sleep(5)
else:
   input ("relancez le logiciel pour rechoisir quelque chose...")
