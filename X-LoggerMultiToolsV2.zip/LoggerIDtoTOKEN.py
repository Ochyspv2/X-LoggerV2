import os
import base64
try:
    from colorama import Fore, init
except:
    os.system("py -m pip install colorama")
    from colorama import Fore, init
init()

banner = (Fore.MAGENTA + """
                           ██╗  ██╗     ██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
                           ╚██╗██╔╝     ██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
                            ╚███╔╝█████╗██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
                            ██╔██╗╚════╝██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
                           ██╔╝ ██╗     ███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
                           ╚═╝  ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
""" + Fore.LIGHTCYAN_EX)
print(banner)
userid = input("L'id de l'utilsateur : ")
encodedBytes = base64.b64encode(userid.encode("utf-8"))
encodedStr = str(encodedBytes, "utf-8")
print(f'\n  Le token commence par : {encodedStr}')
print ("discord.gg/wojack")
os.system('pause >nul')
