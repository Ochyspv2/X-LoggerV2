import tkinter as tk
from tkinter import messagebox
import requests

def envoyer_message_webhook():
    webhook_url = webhook_entry.get()
    message = message_entry.get()
    nombre_messages = int(nombre_messages_entry.get())
    
    for _ in range(nombre_messages):
        data = {"content": message}
        response = requests.post(webhook_url, json=data)
        if response.status_code == 200:
            result_label.config(text=f"spam reussi({_ + 1}/{nombre_messages}).")
        else:
            result_label.config(text=f"Erreur {response.status_code}")

fenetre = tk.Tk()
fenetre.title("X-Logger Webnhook spammer")

# Charger l'icône
icone_path = "X-.ico"  
if icone_path:
    fenetre.iconbitmap(icone_path)

webhook_label = tk.Label(fenetre, text="Webhook URL:")
webhook_label.grid(row=0, column=0, sticky=tk.E)
webhook_entry = tk.Entry(fenetre)
webhook_entry.grid(row=0, column=1, columnspan=2)

message_label = tk.Label(fenetre, text="Message:")
message_label.grid(row=1, column=0, sticky=tk.E)
message_entry = tk.Entry(fenetre)
message_entry.grid(row=1, column=1, columnspan=2)

nombre_messages_label = tk.Label(fenetre, text="Nombre de messages:")
nombre_messages_label.grid(row=2, column=0, sticky=tk.E)
nombre_messages_entry = tk.Entry(fenetre)
nombre_messages_entry.grid(row=2, column=1, columnspan=2)

envoyer_button = tk.Button(fenetre, text="Envoyer", command=envoyer_message_webhook)
envoyer_button.grid(row=3, column=0, columnspan=3, pady=10)

result_label = tk.Label(fenetre, text="")
result_label.grid(row=4, column=0, columnspan=3)

fenetre.mainloop()
