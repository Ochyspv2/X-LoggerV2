
import requests
import random
import string
import time

print("""

                       ██╗  ██╗     ██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
                       ╚██╗██╔╝     ██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
                        ╚███╔╝█████╗██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
                        ██╔██╗╚════╝██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
                       ██╔╝ ██╗     ███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
                       ╚═╝  ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝""")
time.sleep(2)
print("Nitro generateur")
time.sleep(0.3)
print("ajoutez ochychan sur discord si il y a un bug\n")
time.sleep(0.2)

num = int(input('combien de code tu veux gen : '))

with open("nitrocodeinvalid.txt", "w", encoding='utf-8') as file:
    print("Vos codes son entrain de ce genere")

    start = time.time()

    for i in range(num):
        code = "".join(random.choices(
            string.ascii_uppercase + string.digits + string.ascii_lowercase,
            k = 16
        ))

        file.write(f"https://discord.gift/{code}\n")

    print(f"Generated {num} codes | Time taken: {time.time() - start}\n")

with open("nitrocodeinvalid.txt") as file:
    for line in file.readlines():
        nitro = line.strip("\n")

        url = "https://discordapp.com/api/v6/entitlements/gift-codes/" + nitro + "?with_application=false&with_subscription_plan=true"

        r = requests.get(url)

        if r.status_code == 200:
            print(f" Valid gg | {nitro} ")
            break
        else:
            print(f" Invalid desolay| {nitro} ")

input("\nles codes on été gen vous pouvez relancez le tool pour re gen !")
